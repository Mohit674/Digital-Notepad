import streamlit as st
import pandas as pd
import plotly.express as px
from PIL import Image
import os
import uuid
from datetime import datetime
from streamlit_drawable_canvas import st_canvas

# Initialize session state for notes metadata
if 'notes' not in st.session_state:
    st.session_state.notes = pd.DataFrame(columns=['ID', 'Title', 'Type', 'FilePath', 'Created', 'Description'])

# Create notes directory
NOTES_DIR = "notes"
if not os.path.exists(NOTES_DIR):
    os.makedirs(NOTES_DIR)

# Function to save metadata to CSV
def save_metadata():
    st.session_state.notes.to_csv('notes_metadata.csv', index=False)

# Function to load metadata from CSV
def load_metadata():
    if os.path.exists('notes_metadata.csv'):
        df = pd.read_csv('notes_metadata.csv')
        df['Created'] = pd.to_datetime(df['Created'])
        st.session_state.notes = df

# Load existing metadata
load_metadata()

# Function to save image file
def save_image(uploaded_file, prefix="image"):
    file_id = str(uuid.uuid4())
    file_ext = os.path.splitext(uploaded_file.name)[1].lower()
    filename = f"{prefix}_{file_id}{file_ext}"
    file_path = os.path.join(NOTES_DIR, filename)
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return filename, file_path

# Streamlit app layout
st.title("Digital Notepad")
st.write("Create typed, handwritten, or image-based notes!")

# Sidebar for note creation
st.sidebar.header("Create Note")
note_type = st.sidebar.selectbox("Note Type", ["Typed", "Handwritten", "Image"])
note_title = st.sidebar.text_input("Note Title")
note_description = st.sidebar.text_area("Description (optional)")

# Typed note
if note_type == "Typed":
    typed_content = st.text_area("Type your note here", height=200)
    if st.button("Save Typed Note"):
        if note_title and typed_content:
            file_id = str(uuid.uuid4())
            filename = f"typed_{file_id}.txt"
            file_path = os.path.join(NOTES_DIR, filename)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(typed_content)
            new_note = pd.DataFrame({
                'ID': [file_id],
                'Title': [note_title],
                'Type': ['Typed'],
                'FilePath': [file_path],
                'Created': [datetime.now()],
                'Description': [note_description]
            })
            st.session_state.notes = pd.concat([st.session_state.notes, new_note], ignore_index=True)
            save_metadata()
            st.success("Typed note saved!")
        else:
            st.error("Title and content are required.")

# Handwritten note
elif note_type == "Handwritten":
    st.write("Draw your note below:")
    canvas_result = st_canvas(
        stroke_width=2,
        stroke_color="#000000",
        background_color="#ffffff",
        height=400,
        width=600,
        drawing_mode="freedraw",
        key="canvas"
    )
    if st.button("Save Handwritten Note"):
        if note_title and canvas_result.image_data is not None:
            image = Image.frombytes("RGBA", canvas_result.image_data.shape[1::-1], canvas_result.image_data)
            file_id = str(uuid.uuid4())
            filename = f"handwritten_{file_id}.png"
            file_path = os.path.join(NOTES_DIR, filename)
            image.save(file_path)
            new_note = pd.DataFrame({
                'ID': [file_id],
                'Title': [note_title],
                'Type': ['Handwritten'],
                'FilePath': [file_path],
                'Created': [datetime.now()],
                'Description': [note_description]
            })
            st.session_state.notes = pd.concat([st.session_state.notes, new_note], ignore_index=True)
            save_metadata()
            st.success("Handwritten note saved!")
        else:
            st.error("Title and drawing are required.")

# Image note
elif note_type == "Image":
    uploaded_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])
    if uploaded_file and st.button("Save Image Note"):
        if note_title:
            filename, file_path = save_image(uploaded_file, prefix="image")
            new_note = pd.DataFrame({
                'ID': [filename.split('.')[0].split('_')[1]],
                'Title': [note_title],
                'Type': ['Image'],
                'FilePath': [file_path],
                'Created': [datetime.now()],
                'Description': [note_description]
            })
            st.session_state.notes = pd.concat([st.session_state.notes, new_note], ignore_index=True)
            save_metadata()
            st.success("Image note saved!")
        else:
            st.error("Title is required.")

# Notes gallery
st.header("Notes Gallery")
if not st.session_state.notes.empty:
    for _, row in st.session_state.notes.iterrows():
        st.subheader(row['Title'])
        st.write(f"**Type**: {row['Type']}")
        st.write(f"**Created**: {row['Created']}")
        st.write(f"**Description**: {row['Description']}")
        if row['Type'] == "Typed":
            with open(row['FilePath'], "r", encoding="utf-8") as f:
                st.text(f.read())
        else:  # Handwritten or Image
            st.image(row['FilePath'], caption=row['Title'], use_column_width=True)
        st.markdown("---")
else:
    st.write("No notes yet. Create one in the sidebar!")

# Visualizations
st.header("Notes Insights")
if not st.session_state.notes.empty:
    # Pie chart for note types
    type_counts = st.session_state.notes['Type'].value_counts().reset_index()
    type_counts.columns = ['Type', 'Count']
    fig_pie = px.pie(type_counts, values='Count', names='Type', title="Note Type Distribution",
                     color_discrete_sequence=px.colors.sequential.Blues)
    st.plotly_chart(fig_pie)

    # Bar chart for notes by creation date
    st.session_state.notes['Date'] = st.session_state.notes['Created'].dt.date
    date_counts = st.session_state.notes['Date'].value_counts().reset_index()
    date_counts.columns = ['Date', 'Count']
    fig_bar = px.bar(date_counts, x='Date', y='Count', title="Notes by Creation Date",
                     color='Count', color_continuous_scale='Viridis')
    st.plotly_chart(fig_bar)
else:
    st.write("Create notes to see insights.")